# Tadil version 77

Continuation of the uploaded version 76 Windows/Python application. Source and installer build scripts are in Tadil_v77; unmodified baseline code and assets are in reference_v76. See Tadil_v77/README_FA.md for installation and Tadil_v77/RELEASE_REPORT_FA.md for fixes, evidence and testing limitations.

Private customer databases and development tool downloads are not included in this repository. The installer executable is a separate build artifact.
